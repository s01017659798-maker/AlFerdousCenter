package eg.alfardous.center;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String id=intent.getStringExtra("id"), title=intent.getStringExtra("title"), body=intent.getStringExtra("body");
        NotificationScheduler.ensureChannel(context);
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED) {
            Intent open=new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent content=PendingIntent.getActivity(context, (id==null?"reminder":id).hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification n=new NotificationCompat.Builder(context,NotificationScheduler.CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title==null?"سنتر الفردوس":title)
                .setContentText(body==null?"لديك تذكير":body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(content).build();
            ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify((id==null?"reminder":id).hashCode(),n);
        }
        if(intent.getBooleanExtra("weekly",false) && id!=null) {
            try { JSONObject row=new JSONObject(context.getSharedPreferences(NotificationScheduler.PREFS,0).getString(id,"{}"));
                row.put("at",intent.getLongExtra("at",System.currentTimeMillis())+7L*24*60*60*1000); NotificationScheduler.schedule(context,row);
            } catch(Exception ignored) {}
        } else if(id!=null) NotificationScheduler.cancel(context,id);
    }
}

package eg.alfardous.center;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.SharedPreferences;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import org.json.JSONArray;
import org.json.JSONObject;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.view.View;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
    private static final int FILE_PICKER = 4207;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 4208;
    private WebView web;
    private ValueCallback<Uri[]> chooserCallback;
    private String pendingName = "export";
    private String pendingMime = "application/octet-stream";
    private ByteArrayOutputStream pendingBytes = new ByteArrayOutputStream();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFFFFFFFF);
        // Android 15 / edge-to-edge: keep WebView content clear of system bars.
        ViewCompat.setOnApplyWindowInsetsListener(web, (view, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(0, bars.top, 0, bars.bottom);
            return windowInsets;
        });
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new AndroidFileBridge(), "AndroidFileBridge");
        web.addJavascriptInterface(new AndroidNotificationBridge(), "AndroidNotificationBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                String host = uri.getHost() == null ? "" : uri.getHost();
                if ("file".equals(scheme) && uri.getPath() != null && uri.getPath().startsWith("/android_asset/")) return false;
                if ("https".equals(scheme) || "http".equals(scheme) || "tel".equals(scheme) || "mailto".equals(scheme) || "whatsapp".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {
                        Toast.makeText(MainActivity.this, "تعذر فتح الرابط الخارجي", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return true; // block every other scheme/navigation inside the privileged WebView
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_PICKER); return true; }
                catch (Exception e) { chooserCallback = null; return false; }
            }
        });
        setContentView(web);
        ViewCompat.requestApplyInsets(web);
        web.loadUrl("file:///android_asset/index.html");
    }


    public class AndroidNotificationBridge {
        @JavascriptInterface public void requestPermission() {
            runOnUiThread(() -> {
                NotificationScheduler.ensureChannel(MainActivity.this);
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                } else {
                    NotificationScheduler.ensureChannel(MainActivity.this);
                    Toast.makeText(MainActivity.this, "إشعارات التطبيق مفعّلة أو مسموح بها بالفعل", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface public void syncReminders(String json) {
            runOnUiThread(() -> {
                try {
                    JSONArray rows = new JSONArray(json == null ? "[]" : json);
                    NotificationScheduler.replaceAll(MainActivity.this, rows);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر تحديث مواعيد الإشعارات", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public class AndroidFileBridge {
        @JavascriptInterface public void begin(String filename, String mime) {
            pendingName = filename == null ? "export" : filename.substring(filename.lastIndexOf('/') + 1).replace("\\", "_");
            if (pendingName.trim().isEmpty()) pendingName = "export";
            pendingMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            pendingBytes = new ByteArrayOutputStream();
        }
        @JavascriptInterface public void append(String chunk) {
            try { pendingBytes.write(Base64.decode(chunk, Base64.DEFAULT)); } catch (Exception ignored) { }
        }
        @JavascriptInterface public void finish() {
            runOnUiThread(() -> {
                try {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, pendingName);
                    values.put(MediaStore.Downloads.MIME_TYPE, pendingMime);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("تعذر إنشاء ملف التنزيل");
                    try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IllegalStateException("تعذر فتح ملف التنزيل");
                        pendingBytes.writeTo(out);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                    Toast.makeText(MainActivity.this, "تم حفظ الملف في مجلد التنزيلات", Toast.LENGTH_LONG).show();
                    pendingBytes = new ByteArrayOutputStream();
                    notifyFileSaveResult(true);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر حفظ الملف: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    notifyFileSaveResult(false);
                }
            });
        }
        private void notifyFileSaveResult(boolean success) {
            if (web != null) web.evaluateJavascript("(function(){var r=window.__centerFileSaveResolve;if(r){window.__centerFileSaveResolve=null;r(" + success + ");}})()", null);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            Toast.makeText(this, granted ? "تم السماح بإشعارات سنتر الفردوس" : "لم يتم السماح بالإشعارات؛ يمكنك تفعيلها من إعدادات الهاتف", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER) {
            Uri[] result = (resultCode == RESULT_OK && data != null) ? WebChromeClient.FileChooserParams.parseResult(resultCode, data) : null;
            if (chooserCallback != null) chooserCallback.onReceiveValue(result);
            chooserCallback = null;
        }
    }

    @Override protected void onDestroy() {
        if (chooserCallback != null) { chooserCallback.onReceiveValue(null); chooserCallback = null; }
        if (web != null) {
            web.removeJavascriptInterface("AndroidFileBridge");
            web.removeJavascriptInterface("AndroidNotificationBridge");
            web.stopLoading();
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');

test('reminder modules use the lexical database and no longer exit on missing window.db', () => {
  assert.match(html, /if\(typeof db==='undefined'\|\|!db\)return;/);
  assert.match(html, /if\(!bridge \|\| typeof db==='undefined' \|\| !db\) return;/);
  assert.doesNotMatch(html, /if\(!window\.db\)return;/);
  assert.doesNotMatch(html, /!window\.db\) return;/);
});

test('classroom interaction records have a form, list, edit, delete, and student profile history', () => {
  for (const id of ['interactions','interactionForm','interactionGroup','interactionStudent','interactionRows','profileInteractions']) {
    assert.match(html, new RegExp(`id="${id}"`));
  }
  for (const fn of ['editInteractionRecord','deleteInteractionRecord','renderInteractionRecords','cancelInteractionEdit']) {
    assert.match(html, new RegExp(`window\\.${fn}\\s*=`));
  }
  assert.match(html, /interactionRecords/);
  assert.match(html, /هذا السجل خارج المجموعات المسندة إليك/);
});

test('interaction records and general reminders are included in backup and restore defaults', () => {
  assert.match(html, /optionalArrays=\[[^\]]*interactionRecords[^\]]*centerReminders/);
  assert.match(html, /centerReminders:\[\],interactionRecords:\[\]/);
});

test('new build version is 3.8.9', () => {
  assert.match(gradle, /versionCode 389/);
  assert.match(gradle, /versionName '3\.8\.9'/);
});

test('exam and exam-result WhatsApp sharing are removed', () => {
  assert.doesNotMatch(html, /shareExamToWhatsApp|shareExamAttempt/);
  assert.doesNotMatch(html, /onclick="shareExam(ToWhatsApp|Attempt)\(/);
});

test('exam editing supports metadata and individual question changes', () => {
  assert.match(html, /onclick="editExam\(\$\{x\.id\}\)"/);
  assert.match(html, /onclick="editExamQuestions\(\$\{x\.id\}\)"/);
  assert.match(html, /function editExamQuestions\(id\)/);
});

test('student portal includes classroom interaction history', () => {
  assert.match(html, /سجلات التفاعل/);
  assert.match(html, /تفاعل الحصص/);
  assert.match(html, /profileInteractions/);
});

test('restoring a backup forces native Android reminders to be synchronized', () => {
  assert.match(html, /syncAlfardousNativeReminders\(true\)/);
  assert.match(html, /window\.syncAlfardousNativeReminders=function\(force\)/);
});
